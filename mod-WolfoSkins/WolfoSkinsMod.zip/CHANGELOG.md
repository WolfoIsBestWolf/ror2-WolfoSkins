## Changelog
```
v1.9.11
Fixed a error during startup if the unlock all config was enabled.

v1.9.10
Fixes infinite loading with CHEF_MOD and Paladin being bugged.

v1.9.9 - Sots Fix
Skins for Sots characters and variants of Sots skins will come at a later time. 
Removed Prismatic Trial/Dissonant Achievements.
Fixed bug with Unlock All config causing issues on with modded survivor skins.

v1.6.2
Fixed a bug where attacks with visual overlays such as Mercs could break modded code.
Added Executioner : Blue/Green
Added Nemesis Enfrocer : Big Yellow

v1.6.1
Fixed Arsonist, Tesla, Desolator skins not unlocking.

v1.6.0
Added Arsonist : Orange
Added Arsonist : Blue
Added Arsonist : Blue GM
Added Tesla Trooper Colors : White, Strong Blue, Neon Blue, Neon Cyan, Hot Pink, Neon Red
Added Desolator Colors : Gray, Strong Green, Neon Green, Safety Yellow, Neon Yellow, Neon Orange
Added Paladin : Gold/Green

Hid placeholder prism achievements.
Gave CHEF colored cleavers.
Fixed CHEF alt primary arm color not changing with skins.
Made Ravager skin look less weird.

v1.5.0
Added Han-D : Green/Yellow
Added Han-D : Green/Yellow GM
Added Acrid : Black/Green
Added CHEF : Blue
Added CHEF : Red/Cyan
Added Sniper : Gray
Added Artificer : Purple/Yellow
Added Rocket : Red
Added Rocket : Blue
Added Ravager : Red/Black
Added Pilot : Blue/Yellow
Added Pilot : White/Black/Red
Added Pilot : Red/Purple/Cyan
Added Void Fiend : Orange
Added Enforcer : Yellow
Added Miner : Black/Orange
Added Miner : Orange
Added Miner : Emerald
Added Chirr : Pink/White/Green
Added Chirr : Orange/Yellow

Added another achievement type (Beat run with Dissonance or beat Prismatic run)
Skins are now sorted later than Grand Mastery and other skin mods.

v1.4.0
Added Han-D : Orange/Black
Added Han-D : Orange/Black GM
Added Executioner : Mastery Yellow
Added CHEF : Green
Added CHEF : Cyan/Pink/White
Added Bandit : Yellow Hat/Lime
Added Loader : Red
Added Bandit : Blue/Yellow
Added Sniper : Orange

Achievements for modded characters are now hidden if the mod is not installed.

Executioner Skins now have colored smoke trails and overlay mat
-Can't really do much more with R2API.SkinsVFX at the moment

Commando (Provi Trial) Guns are now silverish color
CHEF (Black) Now has white facial features

v1.3.0
Added Railgunner : Green/Brown
Added Executioner : Black/Red
Engi Skins : Added more Light patterns and better Blue Harpoons

Loader (Green) now uses default skin mech.
Fixed Enforcer Skin not unlocking

v1.2.0
Made it it's own mod instead of being part of SimulacrumAdditions.
Skins can now be unlocked by beating Twisted Scavengers too.

Updated various skins
Added 5 more Skins
-Added Huntress : Bee
-Added Acrid : Lemurian
-Added REX : Red/Yellow/Black
-Added Engineer : Blue/Pink
-Added Enforcer : Red/Blue/Yellow


Added config for no unlock requirement
Added config to nerf Voidlings stats (not changed by default) or limit his level to 99 for level cap raising mods (on by default)

v1.1.1 - (Simulacrum Additions)
-Added Commando : Provi
-Added Commando : Black Hat/Purple

v1.1.0 - (Simulacrum Additions update)
-Captain Red/Black
-Mul-T : Damage
-Mul-T : Healing
-Artificer : Orange/Black
-Artificer : Rainbow
-Huntress : Black/Pink
-Acrid : White/Blue
-CHEF : Red
-CHEF : Black
-Han-D : Gold
-Han-D : Gold GM
-Loader : (Green)
-Mercenary : (Blue/Gray)
-Mercenary : (Red/Gray)
-Void Fiend : (Black/Red
-Void Fiend : (White/Blue)
-Railgunner : (White/Black/Blue)

v1.0.5 (LittleGameplayTweaks)
-Bandit (Red Hat/Light Brown)

v1.0.0 (LittleGameplayTweaks)
-Commando : (Unused SotV skin)
-REX : Blue
-Captain : Pink

